﻿namespace $safeprojectname$.Models
{
    public class BasicModel
    {
    }
}
