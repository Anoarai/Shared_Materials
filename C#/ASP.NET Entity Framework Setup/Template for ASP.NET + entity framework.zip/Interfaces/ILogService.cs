﻿namespace $safeprojectname$.Interfaces
{
    public interface ILogService
    {
        void AddLog(string method, string functionName, string Parameters);
    }
}
