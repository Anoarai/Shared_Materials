﻿namespace $safeprojectname$.Interfaces
{
    public interface IPostService
    {
    }
}
