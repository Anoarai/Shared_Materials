﻿namespace $safeprojectname$.Models
{
    public class Post
    {
    }
}
