﻿namespace $safeprojectname$.ViewModels
{
    public class IndexViewModel
    {
    }
}
