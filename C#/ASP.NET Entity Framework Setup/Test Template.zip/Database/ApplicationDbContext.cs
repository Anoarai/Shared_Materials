﻿using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Models;

namespace $safeprojectname$.Database
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Post> Posts { get; set; }


        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Post>().HasKey(l => l.Id);
        }
    }
}
