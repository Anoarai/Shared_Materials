﻿using $safeprojectname$.Database;
using $safeprojectname$.Interfaces;
using $safeprojectname$.Models;

namespace $safeprojectname$.Services
{
    public class PostService : IPostService
    {
        private ApplicationDbContext database;

        public PostService(ApplicationDbContext database)
        {
            this.database = database;
        }
    }
}
